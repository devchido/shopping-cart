import React, { Component } from 'react'

class NotFound extends Component {
    render() {
        return (
            <div style={{ margin: '150px' }}>
                <h1 className="display-4">Page Not Found</h1>
                <p>Sorry, This page does not exist</p>
            </div>

        )
    }
}

export default NotFound
