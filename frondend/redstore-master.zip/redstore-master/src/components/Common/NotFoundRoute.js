import React, { Component } from 'react'

export class NotFoundRoute extends Component {
    render() {
        return (
            <div>
                <h1>Building...</h1>
            </div>
        )
    }
}

export default NotFoundRoute
