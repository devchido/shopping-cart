package com.example.redstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedstoreApplication.class, args);
	}

}
